(function(){const _="custom-yt-chat-input-overlay",N="sendWithEnter",y="fontSize";let p=null;chrome.runtime.onMessage.addListener(t=>{var c;if(t.type==="CLOSE_CHAT_OVERLAY")return(c=document.getElementById(_))==null||c.remove(),p=null,!1;if(t.type==="TEXT_COUNT_UPDATED")return p&&(p.textContent=`${t.count} / ${t.limit}`,p.classList.toggle("near-limit",t.count<=t.limit&&t.limit-t.count<=10),p.classList.toggle("over-limit",t.count>t.limit)),!1;if(t.type!=="TOGGLE_CHAT_OVERLAY")return!1;const e=document.getElementById(_);return e?e.remove():I(t.tabId),!1});async function I(t){const e=document.createElement("div");e.id=_;const c=e.attachShadow({mode:"closed"}),o=document.createElement("style");o.textContent=`
    :host { all: initial; }
    .panel {
      position: fixed;
      right: 0;
      bottom: 0;
      z-index: 2147483647;
      display: flex;
      width: min(560px, calc(100vw - 24px));
      height: 135px;
      min-width: 320px;
      min-height: 108px;
      max-width: calc(100vw - 8px);
      max-height: calc(100vh - 8px);
      flex-direction: column;
      overflow: hidden;
      border: 1px solid #3f3f3f;
      border-radius: 14px;
      background: #0f0f0f;
      box-shadow: 0 12px 48px rgb(0 0 0 / 45%);
    }
    .bar {
      display: flex;
      height: 26px;
      align-items: center;
      justify-content: space-between;
      background: #212121;
      padding: 0 5px 0 9px;
      color: #f1f1f1;
      font: 11px/1 system-ui, sans-serif;
      user-select: none;
    }
    .drag-handle {
      display: flex;
      height: 100%;
      flex: 1;
      align-items: center;
      cursor: move;
    }
    .controls { display: flex; align-items: center; gap: 7px; }
    .font-counter {
      display: flex;
      align-items: center;
      gap: 2px;
      color: #aaa;
      font: 11px/1 system-ui, sans-serif;
    }
    .counter-button {
      width: 20px;
      height: 20px;
      border: 0;
      border-radius: 4px;
      background: transparent;
      color: #aaa;
      font: 16px/1 system-ui, sans-serif;
      cursor: pointer;
    }
    .counter-button:hover { background: #3f3f3f; color: #fff; }
    .counter-button:disabled { color: #555; cursor: default; }
    .font-size { width: 20px; text-align: center; }
    .character-counter {
      min-width: 48px;
      color: #aaa;
      font: 10px/1 system-ui, sans-serif;
      text-align: right;
      white-space: nowrap;
    }
    .character-counter.near-limit { color: #ffd54f; font-weight: 700; }
    .character-counter.over-limit { color: #ff6b6b; font-weight: 700; }
    .auth-button {
      height: 20px;
      border: 0;
      border-radius: 4px;
      background: #9147ff;
      padding: 0 7px;
      color: #fff;
      font: 10px/1 system-ui, sans-serif;
      cursor: pointer;
    }
    .auth-button:disabled { background: #444; color: #aaa; cursor: default; }
    .switch-label {
      display: flex;
      align-items: center;
      gap: 6px;
      color: #aaa;
      font-size: 10px;
      cursor: pointer;
    }
    .switch-label input { position: absolute; width: 1px; height: 1px; opacity: 0; }
    .switch {
      position: relative;
      width: 28px;
      height: 14px;
      border-radius: 999px;
      background: #555;
    }
    .switch::after {
      position: absolute;
      top: 2px;
      left: 2px;
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background: #fff;
      content: "";
      transition: transform 120ms ease;
    }
    .switch-label input:checked + .switch { background: #3ea6ff; }
    .switch-label input:checked + .switch::after { transform: translateX(14px); }
    .switch-label input:focus-visible + .switch { outline: 2px solid #fff; }
    .close {
      display: grid;
      width: 22px;
      height: 22px;
      place-items: center;
      border: 0;
      border-radius: 50%;
      background: transparent;
      color: #aaa;
      font: 18px/1 sans-serif;
      cursor: pointer;
    }
    .close:hover { background: #3f3f3f; color: #fff; }
    iframe { display: block; width: 100%; min-height: 0; flex: 1; border: 0; }
    .resize-handle {
      position: absolute;
      right: 0;
      bottom: 0;
      z-index: 2;
      width: 18px;
      height: 18px;
      cursor: nwse-resize;
    }
    .resize-handle::after {
      position: absolute;
      right: 4px;
      bottom: 4px;
      width: 7px;
      height: 7px;
      border-right: 2px solid #777;
      border-bottom: 2px solid #777;
      content: "";
    }
  `;const a=document.createElement("section");a.className="panel",a.setAttribute("aria-label","YouTube Live Chat Input");const h=document.createElement("div");h.className="bar";const l=document.createElement("span");l.className="drag-handle",l.textContent="ニコタイチャット";const i=document.createElement("div");i.className="controls";const d=document.createElement("label");d.className="switch-label";const m=document.createElement("span"),n=document.createElement("input");n.type="checkbox",n.setAttribute("role","switch");const w=await chrome.storage.local.get([N,y]);n.checked=w[N]===!0,n.setAttribute("aria-checked",String(n.checked)),m.textContent=n.checked?"Enter":"Ctrl+Enter";const E=document.createElement("span");E.className="switch",E.setAttribute("aria-hidden","true"),n.addEventListener("change",()=>{n.setAttribute("aria-checked",String(n.checked)),m.textContent=n.checked?"Enter":"Ctrl+Enter",chrome.storage.local.set({[N]:n.checked})}),d.append(m,n,E);let u=typeof w[y]=="number"?w[y]:18;const T=document.createElement("div");T.className="font-counter";const f=document.createElement("button");f.type="button",f.className="counter-button",f.setAttribute("aria-label","文字を小さくする"),f.textContent="−";const k=document.createElement("span");k.className="font-size";const x=document.createElement("button");x.type="button",x.className="counter-button",x.setAttribute("aria-label","文字を大きくする"),x.textContent="+";const C=g=>{u=Math.min(Math.max(g,12),32),k.textContent=String(u),f.disabled=u<=12,x.disabled=u>=32,a.style.height=`${54+u*4.5}px`,chrome.storage.local.set({[y]:u})};f.addEventListener("click",()=>C(u-1)),x.addEventListener("click",()=>C(u+1)),C(u),T.append(f,k,x),p=document.createElement("span"),p.className="character-counter",p.textContent=location.hostname.endsWith("twitch.tv")?"0 / 500":"0 / 200";const s=document.createElement("button");if(s.type="button",s.className="auth-button",s.textContent="確認中…",s.disabled=!0,location.hostname==="www.twitch.tv"||location.hostname==="twitch.tv"){const g=r=>{s.textContent=r?"認証済":"使用するにはTwitch認証してください",s.disabled=r};chrome.runtime.sendMessage({type:"GET_TWITCH_AUTH_STATUS"}).then(r=>g(r.ok&&r.authenticated)).catch(()=>g(!1)),s.addEventListener("click",async()=>{s.textContent="認証中…",s.disabled=!0;try{const r=await chrome.runtime.sendMessage({type:"AUTHENTICATE_TWITCH"});g(r.ok&&r.authenticated),r.ok||(s.title=r.error)}catch(r){g(!1),s.title=r instanceof Error?r.message:String(r)}})}const b=document.createElement("button");b.type="button",b.className="close",b.setAttribute("aria-label","閉じる"),b.textContent="×",b.addEventListener("click",()=>e.remove()),location.hostname.endsWith("twitch.tv")&&i.append(s),i.append(p,T,d,b),h.append(l,i);const L=document.createElement("iframe");L.src=chrome.runtime.getURL(`src/window/index.html?tabId=${encodeURIComponent(t)}&view=overlay`),L.title="チャット入力";const v=document.createElement("div");v.className="resize-handle",v.setAttribute("aria-hidden","true"),a.append(h,L,v),c.append(o,a),document.documentElement.append(e),A(a,l),S(a,v)}function A(t,e){e.addEventListener("pointerdown",c=>{const o=t.getBoundingClientRect(),a=c.clientX-o.left,h=c.clientY-o.top;e.setPointerCapture(c.pointerId);const l=d=>{const m=Math.min(Math.max(0,d.clientX-a),window.innerWidth-t.offsetWidth),n=Math.min(Math.max(0,d.clientY-h),window.innerHeight-t.offsetHeight);t.style.right="auto",t.style.bottom="auto",t.style.left=`${m}px`,t.style.top=`${n}px`},i=()=>{e.removeEventListener("pointermove",l),e.removeEventListener("pointerup",i),e.removeEventListener("pointercancel",i)};e.addEventListener("pointermove",l),e.addEventListener("pointerup",i),e.addEventListener("pointercancel",i)})}function S(t,e){e.addEventListener("pointerdown",c=>{c.preventDefault();const o=t.getBoundingClientRect(),a=c.clientX,h=c.clientY;t.style.right="auto",t.style.bottom="auto",t.style.left=`${o.left}px`,t.style.top=`${o.top}px`,t.style.width=`${o.width}px`,t.style.height=`${o.height}px`,e.setPointerCapture(c.pointerId);const l=d=>{const m=window.innerWidth-o.left,n=window.innerHeight-o.top,w=Math.min(Math.max(320,o.width+d.clientX-a),m),E=Math.min(Math.max(108,o.height+d.clientY-h),n);t.style.width=`${w}px`,t.style.height=`${E}px`},i=()=>{e.removeEventListener("pointermove",l),e.removeEventListener("pointerup",i),e.removeEventListener("pointercancel",i)};e.addEventListener("pointermove",l),e.addEventListener("pointerup",i),e.addEventListener("pointercancel",i)})}
})()
