(function(){const N="custom-yt-chat-input-overlay",C="sendWithEnter",v="fontSize";chrome.runtime.onMessage.addListener(e=>{var r;if(e.type==="CLOSE_CHAT_OVERLAY")return(r=document.getElementById(N))==null||r.remove(),!1;if(e.type!=="TOGGLE_CHAT_OVERLAY")return!1;const t=document.getElementById(N);return t?t.remove():_(e.tabId),!1});async function _(e){const t=document.createElement("div");t.id=N;const r=t.attachShadow({mode:"closed"}),o=document.createElement("style");o.textContent=`
    :host { all: initial; }
    .panel {
      position: fixed;
      right: 0;
      bottom: 0;
      z-index: 2147483647;
      display: flex;
      width: min(560px, calc(100vw - 24px));
      height: 135px;
      min-width: 320px;
      min-height: 108px;
      max-width: calc(100vw - 8px);
      max-height: calc(100vh - 8px);
      flex-direction: column;
      overflow: hidden;
      border: 1px solid #3f3f3f;
      border-radius: 14px;
      background: #0f0f0f;
      box-shadow: 0 12px 48px rgb(0 0 0 / 45%);
    }
    .bar {
      display: flex;
      height: 26px;
      align-items: center;
      justify-content: space-between;
      background: #212121;
      padding: 0 5px 0 9px;
      color: #f1f1f1;
      font: 11px/1 system-ui, sans-serif;
      user-select: none;
    }
    .drag-handle {
      display: flex;
      height: 100%;
      flex: 1;
      align-items: center;
      cursor: move;
    }
    .controls { display: flex; align-items: center; gap: 7px; }
    .font-counter {
      display: flex;
      align-items: center;
      gap: 2px;
      color: #aaa;
      font: 11px/1 system-ui, sans-serif;
    }
    .counter-button {
      width: 20px;
      height: 20px;
      border: 0;
      border-radius: 4px;
      background: transparent;
      color: #aaa;
      font: 16px/1 system-ui, sans-serif;
      cursor: pointer;
    }
    .counter-button:hover { background: #3f3f3f; color: #fff; }
    .counter-button:disabled { color: #555; cursor: default; }
    .font-size { width: 20px; text-align: center; }
    .auth-button {
      height: 20px;
      border: 0;
      border-radius: 4px;
      background: #9147ff;
      padding: 0 7px;
      color: #fff;
      font: 10px/1 system-ui, sans-serif;
      cursor: pointer;
    }
    .auth-button:disabled { background: #444; color: #aaa; cursor: default; }
    .switch-label {
      display: flex;
      align-items: center;
      gap: 6px;
      color: #aaa;
      font-size: 10px;
      cursor: pointer;
    }
    .switch-label input { position: absolute; width: 1px; height: 1px; opacity: 0; }
    .switch {
      position: relative;
      width: 28px;
      height: 14px;
      border-radius: 999px;
      background: #555;
    }
    .switch::after {
      position: absolute;
      top: 2px;
      left: 2px;
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background: #fff;
      content: "";
      transition: transform 120ms ease;
    }
    .switch-label input:checked + .switch { background: #3ea6ff; }
    .switch-label input:checked + .switch::after { transform: translateX(14px); }
    .switch-label input:focus-visible + .switch { outline: 2px solid #fff; }
    .close {
      display: grid;
      width: 22px;
      height: 22px;
      place-items: center;
      border: 0;
      border-radius: 50%;
      background: transparent;
      color: #aaa;
      font: 18px/1 sans-serif;
      cursor: pointer;
    }
    .close:hover { background: #3f3f3f; color: #fff; }
    iframe { display: block; width: 100%; min-height: 0; flex: 1; border: 0; }
    .resize-handle {
      position: absolute;
      right: 0;
      bottom: 0;
      z-index: 2;
      width: 18px;
      height: 18px;
      cursor: nwse-resize;
    }
    .resize-handle::after {
      position: absolute;
      right: 4px;
      bottom: 4px;
      width: 7px;
      height: 7px;
      border-right: 2px solid #777;
      border-bottom: 2px solid #777;
      content: "";
    }
  `;const a=document.createElement("section");a.className="panel",a.setAttribute("aria-label","YouTube Live Chat Input");const u=document.createElement("div");u.className="bar";const d=document.createElement("span");d.className="drag-handle",d.textContent="Live Chat Input";const i=document.createElement("div");i.className="controls";const l=document.createElement("label");l.className="switch-label";const h=document.createElement("span"),n=document.createElement("input");n.type="checkbox",n.setAttribute("role","switch");const g=await chrome.storage.local.get([C,v]);n.checked=g[C]===!0,n.setAttribute("aria-checked",String(n.checked)),h.textContent=n.checked?"Enter":"Ctrl+Enter";const w=document.createElement("span");w.className="switch",w.setAttribute("aria-hidden","true"),n.addEventListener("change",()=>{n.setAttribute("aria-checked",String(n.checked)),h.textContent=n.checked?"Enter":"Ctrl+Enter",chrome.storage.local.set({[C]:n.checked})}),l.append(h,n,w);let p=typeof g[v]=="number"?g[v]:18;const y=document.createElement("div");y.className="font-counter";const m=document.createElement("button");m.type="button",m.className="counter-button",m.setAttribute("aria-label","文字を小さくする"),m.textContent="−";const k=document.createElement("span");k.className="font-size";const f=document.createElement("button");f.type="button",f.className="counter-button",f.setAttribute("aria-label","文字を大きくする"),f.textContent="+";const L=b=>{p=Math.min(Math.max(b,12),32),k.textContent=String(p),m.disabled=p<=12,f.disabled=p>=32,a.style.height=`${54+p*4.5}px`,chrome.storage.local.set({[v]:p})};m.addEventListener("click",()=>L(p-1)),f.addEventListener("click",()=>L(p+1)),L(p),y.append(m,k,f);const c=document.createElement("button");if(c.type="button",c.className="auth-button",c.textContent="確認中…",c.disabled=!0,location.hostname==="www.twitch.tv"||location.hostname==="twitch.tv"){const b=s=>{c.textContent=s?"認証済":"使用するにはTwitch認証してください",c.disabled=s};chrome.runtime.sendMessage({type:"GET_TWITCH_AUTH_STATUS"}).then(s=>b(s.ok&&s.authenticated)).catch(()=>b(!1)),c.addEventListener("click",async()=>{c.textContent="認証中…",c.disabled=!0;try{const s=await chrome.runtime.sendMessage({type:"AUTHENTICATE_TWITCH"});b(s.ok&&s.authenticated),s.ok||(c.title=s.error)}catch(s){b(!1),c.title=s instanceof Error?s.message:String(s)}})}const x=document.createElement("button");x.type="button",x.className="close",x.setAttribute("aria-label","閉じる"),x.textContent="×",x.addEventListener("click",()=>t.remove()),location.hostname.endsWith("twitch.tv")&&i.append(c),i.append(y,l,x),u.append(d,i);const T=document.createElement("iframe");T.src=chrome.runtime.getURL(`src/window/index.html?tabId=${encodeURIComponent(e)}&view=overlay`),T.title="チャット入力";const E=document.createElement("div");E.className="resize-handle",E.setAttribute("aria-hidden","true"),a.append(u,T,E),r.append(o,a),document.documentElement.append(t),I(a,d),A(a,E)}function I(e,t){t.addEventListener("pointerdown",r=>{const o=e.getBoundingClientRect(),a=r.clientX-o.left,u=r.clientY-o.top;t.setPointerCapture(r.pointerId);const d=l=>{const h=Math.min(Math.max(0,l.clientX-a),window.innerWidth-e.offsetWidth),n=Math.min(Math.max(0,l.clientY-u),window.innerHeight-e.offsetHeight);e.style.right="auto",e.style.bottom="auto",e.style.left=`${h}px`,e.style.top=`${n}px`},i=()=>{t.removeEventListener("pointermove",d),t.removeEventListener("pointerup",i),t.removeEventListener("pointercancel",i)};t.addEventListener("pointermove",d),t.addEventListener("pointerup",i),t.addEventListener("pointercancel",i)})}function A(e,t){t.addEventListener("pointerdown",r=>{r.preventDefault();const o=e.getBoundingClientRect(),a=r.clientX,u=r.clientY;e.style.right="auto",e.style.bottom="auto",e.style.left=`${o.left}px`,e.style.top=`${o.top}px`,e.style.width=`${o.width}px`,e.style.height=`${o.height}px`,t.setPointerCapture(r.pointerId);const d=l=>{const h=window.innerWidth-o.left,n=window.innerHeight-o.top,g=Math.min(Math.max(320,o.width+l.clientX-a),h),w=Math.min(Math.max(108,o.height+l.clientY-u),n);e.style.width=`${g}px`,e.style.height=`${w}px`},i=()=>{t.removeEventListener("pointermove",d),t.removeEventListener("pointerup",i),t.removeEventListener("pointercancel",i)};t.addEventListener("pointermove",d),t.addEventListener("pointerup",i),t.addEventListener("pointercancel",i)})}
})()
