(function(){const A="custom-yt-chat-input-overlay",_="sendWithEnter",k="fontSize";let h=null,v=null;chrome.storage.local.onChanged.addListener(t=>{if(t.twitchAuth&&v){const e=!!t.twitchAuth.newValue;v.hidden=e,e||(v.textContent="使用するにはTwitch認証してください",v.disabled=!1)}});chrome.runtime.onMessage.addListener(t=>{var c;if(t.type==="CLOSE_CHAT_OVERLAY")return(c=document.getElementById(A))==null||c.remove(),h=null,!1;if(t.type==="TEXT_COUNT_UPDATED")return h&&(h.textContent=`${t.count} / ${t.limit}`,h.classList.toggle("near-limit",t.count<=t.limit&&t.limit-t.count<=10),h.classList.toggle("over-limit",t.count>t.limit)),!1;if(t.type!=="TOGGLE_CHAT_OVERLAY")return!1;const e=document.getElementById(A);return e?e.remove():I(t.tabId),!1});async function I(t){const e=document.createElement("div");e.id=A;const c=e.attachShadow({mode:"closed"}),i=document.createElement("style");i.textContent=`
    :host { all: initial; }
    .panel {
      position: fixed;
      right: 0;
      bottom: 0;
      z-index: 2147483647;
      display: flex;
      width: min(560px, calc(100vw - 24px));
      height: 135px;
      min-width: 320px;
      min-height: 108px;
      max-width: calc(100vw - 8px);
      max-height: calc(100vh - 8px);
      flex-direction: column;
      overflow: hidden;
      border: 1px solid #3f3f3f;
      border-radius: 14px;
      background: #0f0f0f;
      box-shadow: 0 12px 48px rgb(0 0 0 / 45%);
    }
    .bar {
      display: flex;
      height: 26px;
      align-items: center;
      justify-content: space-between;
      background: #212121;
      padding: 0 5px 0 9px;
      color: #f1f1f1;
      font: 11px/1 system-ui, sans-serif;
      user-select: none;
    }
    .drag-handle {
      display: flex;
      height: 100%;
      flex: 1;
      align-items: center;
      cursor: move;
    }
    .controls { display: flex; align-items: center; gap: 7px; }
    .font-counter {
      display: flex;
      align-items: center;
      gap: 2px;
      color: #aaa;
      font: 11px/1 system-ui, sans-serif;
    }
    .counter-button {
      width: 20px;
      height: 20px;
      border: 0;
      border-radius: 4px;
      background: transparent;
      color: #aaa;
      font: 16px/1 system-ui, sans-serif;
      cursor: pointer;
    }
    .counter-button:hover { background: #3f3f3f; color: #fff; }
    .counter-button:disabled { color: #555; cursor: default; }
    .font-size { width: 20px; text-align: center; }
    .character-counter {
      min-width: 48px;
      color: #aaa;
      font: 10px/1 system-ui, sans-serif;
      text-align: right;
      white-space: nowrap;
    }
    .character-counter.near-limit { color: #ffd54f; font-weight: 700; }
    .character-counter.over-limit { color: #ff6b6b; font-weight: 700; }
    .auth-button {
      height: 20px;
      border: 0;
      border-radius: 4px;
      background: #9147ff;
      padding: 0 7px;
      color: #fff;
      font: 10px/1 system-ui, sans-serif;
      cursor: pointer;
    }
    .auth-button:disabled { background: #444; color: #aaa; cursor: default; }
    .switch-label {
      display: flex;
      align-items: center;
      gap: 6px;
      color: #aaa;
      font-size: 10px;
      cursor: pointer;
    }
    .switch-label input { position: absolute; width: 1px; height: 1px; opacity: 0; }
    .switch {
      position: relative;
      width: 28px;
      height: 14px;
      border-radius: 999px;
      background: #555;
    }
    .switch::after {
      position: absolute;
      top: 2px;
      left: 2px;
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background: #fff;
      content: "";
      transition: transform 120ms ease;
    }
    .switch-label input:checked + .switch { background: #3ea6ff; }
    .switch-label input:checked + .switch::after { transform: translateX(14px); }
    .switch-label input:focus-visible + .switch { outline: 2px solid #fff; }
    .close {
      display: grid;
      width: 22px;
      height: 22px;
      place-items: center;
      border: 0;
      border-radius: 50%;
      background: transparent;
      color: #aaa;
      font: 18px/1 sans-serif;
      cursor: pointer;
    }
    .close:hover { background: #3f3f3f; color: #fff; }
    iframe { display: block; width: 100%; min-height: 0; flex: 1; border: 0; }
    .resize-handle {
      position: absolute;
      right: 0;
      bottom: 0;
      z-index: 2;
      width: 18px;
      height: 18px;
      cursor: nwse-resize;
    }
    .resize-handle::after {
      position: absolute;
      right: 4px;
      bottom: 4px;
      width: 7px;
      height: 7px;
      border-right: 2px solid #777;
      border-bottom: 2px solid #777;
      content: "";
    }
    @media (prefers-color-scheme: light) {
      .panel {
        border-color: #bbb;
        background: #fff;
        box-shadow: 0 12px 48px rgb(0 0 0 / 22%);
      }
      .bar {
        background: #f2f2f2;
        color: #111;
      }
      .font-counter,
      .character-counter,
      .switch-label {
        color: #606060;
      }
      .counter-button { color: #555; }
      .counter-button:hover,
      .close:hover { background: #ddd; color: #111; }
      .counter-button:disabled { color: #bbb; }
      .switch { background: #aaa; }
      .close { color: #666; }
      .resize-handle::after { border-color: #777; }
      .character-counter.near-limit { color: #b26a00; }
      .character-counter.over-limit { color: #d93025; }
    }
  `;const s=document.createElement("section");s.className="panel",s.setAttribute("aria-label","ニコタイチャット");const p=document.createElement("div");p.className="bar";const l=document.createElement("span");l.className="drag-handle",l.textContent="ニコタイチャット";const r=document.createElement("div");r.className="controls";const d=document.createElement("label");d.className="switch-label";const m=document.createElement("span"),n=document.createElement("input");n.type="checkbox",n.setAttribute("role","switch");const w=await chrome.storage.local.get([_,k]);n.checked=w[_]===!0,n.setAttribute("aria-checked",String(n.checked)),m.textContent=n.checked?"Enter":"Ctrl+Enter";const E=document.createElement("span");E.className="switch",E.setAttribute("aria-hidden","true"),n.addEventListener("change",()=>{n.setAttribute("aria-checked",String(n.checked)),m.textContent=n.checked?"Enter":"Ctrl+Enter",chrome.storage.local.set({[_]:n.checked})}),d.append(m,n,E);let u=typeof w[k]=="number"?w[k]:18;const T=document.createElement("div");T.className="font-counter";const f=document.createElement("button");f.type="button",f.className="counter-button",f.setAttribute("aria-label","文字を小さくする"),f.textContent="−";const C=document.createElement("span");C.className="font-size";const b=document.createElement("button");b.type="button",b.className="counter-button",b.setAttribute("aria-label","文字を大きくする"),b.textContent="+";const L=g=>{u=Math.min(Math.max(g,12),32),C.textContent=String(u),f.disabled=u<=12,b.disabled=u>=32,s.style.height=`${54+u*4.5}px`,chrome.storage.local.set({[k]:u})};f.addEventListener("click",()=>L(u-1)),b.addEventListener("click",()=>L(u+1)),L(u),T.append(f,C,b),h=document.createElement("span"),h.className="character-counter",h.textContent=location.hostname.endsWith("twitch.tv")?"0 / 500":"0 / 200";const o=document.createElement("button");if(v=o,o.type="button",o.className="auth-button",o.textContent="確認中…",o.disabled=!0,location.hostname==="www.twitch.tv"||location.hostname==="twitch.tv"){const g=a=>{if(a){o.hidden=!0;return}o.hidden=!1,o.textContent="使用するにはTwitch認証してください",o.disabled=!1};chrome.runtime.sendMessage({type:"GET_TWITCH_AUTH_STATUS"}).then(a=>g(a.ok&&a.authenticated)).catch(()=>g(!1)),o.addEventListener("click",async()=>{o.textContent="認証中…",o.disabled=!0;try{const a=await chrome.runtime.sendMessage({type:"AUTHENTICATE_TWITCH"});g(a.ok&&a.authenticated),a.ok||(o.title=a.error)}catch(a){g(!1),o.title=a instanceof Error?a.message:String(a)}})}const x=document.createElement("button");x.type="button",x.className="close",x.setAttribute("aria-label","閉じる"),x.textContent="×",x.addEventListener("click",()=>e.remove()),location.hostname.endsWith("twitch.tv")&&r.append(o),r.append(h,T,d,x),p.append(l,r);const N=document.createElement("iframe");N.src=chrome.runtime.getURL(`src/window/index.html?tabId=${encodeURIComponent(t)}&view=overlay`),N.title="チャット入力";const y=document.createElement("div");y.className="resize-handle",y.setAttribute("aria-hidden","true"),s.append(p,N,y),c.append(i,s),document.documentElement.append(e),S(s,l),M(s,y)}function S(t,e){e.addEventListener("pointerdown",c=>{const i=t.getBoundingClientRect(),s=c.clientX-i.left,p=c.clientY-i.top;e.setPointerCapture(c.pointerId);const l=d=>{const m=Math.min(Math.max(0,d.clientX-s),window.innerWidth-t.offsetWidth),n=Math.min(Math.max(0,d.clientY-p),window.innerHeight-t.offsetHeight);t.style.right="auto",t.style.bottom="auto",t.style.left=`${m}px`,t.style.top=`${n}px`},r=()=>{e.removeEventListener("pointermove",l),e.removeEventListener("pointerup",r),e.removeEventListener("pointercancel",r)};e.addEventListener("pointermove",l),e.addEventListener("pointerup",r),e.addEventListener("pointercancel",r)})}function M(t,e){e.addEventListener("pointerdown",c=>{c.preventDefault();const i=t.getBoundingClientRect(),s=c.clientX,p=c.clientY;t.style.right="auto",t.style.bottom="auto",t.style.left=`${i.left}px`,t.style.top=`${i.top}px`,t.style.width=`${i.width}px`,t.style.height=`${i.height}px`,e.setPointerCapture(c.pointerId);const l=d=>{const m=window.innerWidth-i.left,n=window.innerHeight-i.top,w=Math.min(Math.max(320,i.width+d.clientX-s),m),E=Math.min(Math.max(108,i.height+d.clientY-p),n);t.style.width=`${w}px`,t.style.height=`${E}px`},r=()=>{e.removeEventListener("pointermove",l),e.removeEventListener("pointerup",r),e.removeEventListener("pointercancel",r)};e.addEventListener("pointermove",l),e.addEventListener("pointerup",r),e.addEventListener("pointercancel",r)})}
})()
